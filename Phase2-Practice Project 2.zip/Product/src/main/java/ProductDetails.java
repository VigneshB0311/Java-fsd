import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String productId = request.getParameter("productId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_schema", "root","rahul559");

            String sql = "SELECT * FROM product WHERE productId = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, productId);
            ResultSet resultSet = statement.executeQuery();

            PrintWriter out = response.getWriter();

            if (resultSet.next()) {
                String productName = resultSet.getString("productName");
                double price = resultSet.getDouble("price");

                out.println("Product ID: " + productId);
                out.println("Product Name: " + productName);
                out.println("Price: $" + price);
            } else {
                out.println("Error: Product not found for ID " + productId);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
