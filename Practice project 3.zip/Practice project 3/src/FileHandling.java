import java.io.*;

public class FileHandling {
    public static void main(String[] args) {
        // File path
        String filePath = "your_file.txt";

        // Write to file
        writeToFile(filePath, "Hello, World!");

        // Read from file
        String content = readFromFile(filePath);
        System.out.println("File content: " + content);

        // Append to file
        appendToFile(filePath, "\nAppended content.");

        // Read again after appending
        content = readFromFile(filePath);
        System.out.println("Updated file content: " + content);
    }

    private static void writeToFile(String filePath, String content) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String readFromFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    private static void appendToFile(String filePath, String content) {
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
