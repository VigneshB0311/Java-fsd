package com.service;
public class UserAuthService {
public String checkUser(String emailid, String password) {
if(emailid.equals("vignesh@gmail.com") && password.equals("Vignesh@2001")) {
return "success";
}else {
return "failure";
}
}}