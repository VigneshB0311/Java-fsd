package com.test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.service.UserAuthService;
class UserAuthServiceTest {
@Test
@DisplayName("Check the user's details")
void testCheckUser() {
//fail("Not yet implemented");
UserAuthService es = new UserAuthService();
String result = es.checkUser("vignesh@gmail.com", "Vignesh@2001");
assertEquals("success", result);
String result1 = es.checkUser("vicky@gmail.com", "123Vicky#456");
assertEquals("failure", result1);
}
}
