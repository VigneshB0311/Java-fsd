let teamBudgets = {};

function addTeamBudget() {
  const teamName = document.getElementById('teamName').value;
  const teamExpenses = parseInt(document.getElementById('teamExpenses').value);
  teamBudgets[teamName] = teamExpenses;
  document.getElementById('teamBudgets').innerText += `${teamName}: $${teamExpenses}\n`;
}

function calculateTotalBudget() {
  let totalBudget = 0;
  for (let team in teamBudgets) {
    totalBudget += teamBudgets[team];
  }
  document.getElementById('totalBudget').innerText = `Total budget for all teams: $${totalBudget}`;
}