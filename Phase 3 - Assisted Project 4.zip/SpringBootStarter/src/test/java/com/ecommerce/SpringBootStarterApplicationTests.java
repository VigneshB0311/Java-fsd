package com.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class SpringBootStarterApplicationTests {

    @Test
    void contextLoads() {
        // Perform a basic sanity check
        assertTrue(true, "The context loads successfully.");
    }
}
