package com.vc.service.user;

import com.vc.entities.User;

public interface UserService {

	public void addUser(User user);
	public User getUser(String email, String password);

}
