package com.vc.service.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vc.entities.Cities;
import com.vc.entities.User;
import com.vc.repository.CityRepository;
import com.vc.repository.UserRepositoory;

@Service
public class GetUserService implements UserService {

	@Autowired
	UserRepositoory repositoory;


	@Override
	public void addUser(User user) {
		repositoory.save(user);
	}

	@Override
	public User getUser(String email,String password) {
		User user = repositoory.findByEmailAndPassword(email,password);
		return user;
	}
	
	

}
