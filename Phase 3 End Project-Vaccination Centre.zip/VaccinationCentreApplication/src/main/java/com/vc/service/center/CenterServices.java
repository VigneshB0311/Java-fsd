package com.vc.service.center;

import java.util.List;

import com.vc.entities.Centers;
import com.vc.entities.Cities;

public interface CenterServices {

	public void addCenter(Centers centers);
	public List<Centers> allCenters();
	public Centers getCenter(int centerid);
	public List<Cities> cityList();
	public void updateCenter(Centers center);
	public void removeCenter(int centerid);

}
