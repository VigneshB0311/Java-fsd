package com.vc.service.center;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vc.entities.Centers;
import com.vc.entities.Cities;
import com.vc.repository.CenterRepository;
import com.vc.repository.CityRepository;

@Service
public class GetCenterService implements CenterServices {

	@Autowired
	CenterRepository centerRepository;
	@Autowired
	CityRepository cityRepository;

	@Override
	public void addCenter(Centers centers) {
		centerRepository.save(centers);
	}

	@Override
	public List<Centers> allCenters() {
		List<Centers> centers = centerRepository.findAll();
		return centers;
	}

	@Override
	public Centers getCenter(int centerid) {
		Centers center = centerRepository.findById(centerid).orElse(null);
		return center;
	}

	@Override
	public List<Cities> cityList() {
		List<Cities> cities = cityRepository.findAll();
		return cities;
	}

	@Override
	public void updateCenter(Centers center) {
		centerRepository.saveAndFlush(center);
	}

	@Override
	public void removeCenter(int centerid) {
		centerRepository.deleteById(centerid);
	}

}
