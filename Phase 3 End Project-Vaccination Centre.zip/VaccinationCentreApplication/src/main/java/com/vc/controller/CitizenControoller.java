package com.vc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vc.entities.Citizens;
import com.vc.service.citizens.CitizensService;

@Controller
public class CitizenControoller {

	@Autowired
	CitizensService citizensService;

	@GetMapping("/citizenlist")
	public void citizenList(Model model) {
		List<Citizens> citizens = citizensService.findAll();
		model.addAttribute("citizenlist", citizens);
	}

	@GetMapping("/deletecitizen")
	public String deleteCenter(@RequestParam("cid") int centerid) {

		citizensService.removeCitizen(centerid);
		return "redirect:/citizenlist";
	}

	@GetMapping("/addcitizen")
	public String addcitizen(Model model) {
		model.addAttribute("cityList", citizensService.cityList());
		return "addcitizen";
	}

	@PostMapping("/addnewcitizen")
	public String addNewCitizen(@ModelAttribute Citizens citizen) {
		citizensService.addCitizen(citizen);
		return "redirect:/citizenlist";
	}

	@GetMapping("/viewcitizen")
	public String viewCitizen(@RequestParam("cid") int citizenid, Model model) {

		Citizens citizen = citizensService.getCitizen(citizenid);
		model.addAttribute("citizen", citizen);
		return "viewcitizen";
	}

	@GetMapping("/updatecitizen")
	public String updateCitizen(@RequestParam("cid") int cid, Model model) {

		Citizens citizen = citizensService.getCitizen(cid);
		model.addAttribute("citizen", citizen);
		model.addAttribute("cityList", citizensService.cityList());

		return "editcitizen";
	}

	@PostMapping("/updatethecitizen")
	public String updateTheCitizen(@ModelAttribute Citizens citizen) {
		citizensService.updateCitizen(citizen);
		return "redirect:/citizenlist";
	}

}
