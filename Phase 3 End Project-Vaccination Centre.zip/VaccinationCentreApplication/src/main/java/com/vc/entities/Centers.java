package com.vc.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Centers {

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private int centerid;

	@Column(name = "Name")
	private String centername;

	@Column(name = "City")
	private String city;

	@OneToMany(mappedBy = "centerid" ,cascade = CascadeType.ALL)
	private List<Citizens> citizens;
}
