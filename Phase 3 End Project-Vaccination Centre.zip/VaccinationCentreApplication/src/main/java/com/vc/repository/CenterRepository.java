package com.vc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vc.entities.Centers;

@Repository
public interface CenterRepository extends JpaRepository<Centers, Integer> {

}
