
package pp4;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class LongestSequence {
 public static List<Integer> findLIS(int[] nums) {
 int n = nums.length;
 int[] lisLength = new int[n];
 Arrays.fill(lisLength, 1);
 for (int i = 1; i < n; i++) {
 for (int j = 0; j < i; j++) {
 if (nums[i] > nums[j] && lisLength[i] < lisLength[j] + 1) {
 lisLength[i] = lisLength[j] + 1;
 }
 }
 }
 int maxLengthIndex = 0;
 for (int i = 1; i < n; i++) {
 if (lisLength[i] > lisLength[maxLengthIndex]) {
 maxLengthIndex = i;
 }
 }
 List<Integer> lis = new ArrayList<>();
 int currentLength = lisLength[maxLengthIndex];
 for (int i = maxLengthIndex; i >= 0; i--) {
 if (lisLength[i] == currentLength) {
 lis.add(nums[i]);
 currentLength--;
 }
 }
 Collections.reverse(lis); 
 return lis;
 }
 public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
 System.out.print("Enter the number of elements: ");
 int n = scanner.nextInt();
 int[] userNumbers = new int[n];
 System.out.print("Enter the elements:");
 for (int i = 0; i < n; i++) {
 userNumbers[i] = scanner.nextInt();
 }
 List<Integer> result = findLIS(userNumbers);
 System.out.println("The longest increasing subsequence is: " + 
result);
 }
}