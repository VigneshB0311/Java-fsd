package org.springframework.cloud.netflix.zuul;

public @interface EnableZuulProxy {

}
