import java.util.*;

class Seat {
    private String seatNumber;
    private boolean isBooked;

    public Seat(String seatNumber) {
        this.seatNumber = seatNumber;
        this.isBooked = false;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void bookSeat() {
        this.isBooked = true;
    }
}

class Movie {
    private String name;

    public Movie(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class ShowTime {
    private String time;
    private List<Seat> seats;
    private Movie movie;

    public ShowTime(String time, int numOfSeats, Movie movie) {
        this.time = time;
        this.seats = new ArrayList<>();
        this.movie = movie;

        for (int i = 1; i <= numOfSeats; i++) {
            seats.add(new Seat("B" + i));
        }
    }

    public String getTime() {
        return time;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public Movie getMovie() {
        return movie;
    }
}

class Theatre {
    private String username;
    private String password;
    private List<ShowTime> showTimes;

    public Theatre(String username, String password) {
        this.username = username;
        this.password = password;
        this.showTimes = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public boolean authenticate(String enteredPassword) {
        return password.equals(enteredPassword);
    }

    public void updatePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password updated successfully.");
    }

    public void addShowTime(String time, int numOfSeats, Movie movie) {
        showTimes.add(new ShowTime(time, numOfSeats, movie));
    }

    public List<ShowTime> getShowTimes() {
        return showTimes;
    }
}

class BookingSystem {
    private Theatre theatre;
    private List<String> bookingStatus;

    public BookingSystem(Theatre theatre) {
        this.theatre = theatre;
        this.bookingStatus = new ArrayList<>();
    }

    public boolean bookTicket(String date, String showTime, String seatSelection) {
        return bookingStatus.add("Booking for " + date + " " + showTime + " - Seat: " + seatSelection + " confirmed.");
    }

    public void viewSeatingArrangement(String date, String showTime, int movieChoice) {
        ShowTime selectedShowTime = getShowTime(date, showTime, movieChoice);

        if (selectedShowTime != null) {
            System.out.println("Seating Arrangement for " + date + " " + showTime + " - Movie: " + selectedShowTime.getMovie().getName() + ":");
            printSeatNumbers();
            printSeatingGrid(selectedShowTime);
        } else {
            System.out.println("Show time not found for the given date.");
        }
    }

    private void printSeatNumbers() {
        System.out.print("Seat Numbers: ");
        for (char row = 'A'; row <= 'C'; row++) {
            for (int seatNum = 1; seatNum <= 5; seatNum++) {
                System.out.print(row + "" + seatNum + " ");
            }
        }
        System.out.println();
    }

    private void printSeatingGrid(ShowTime showTime) {
        System.out.println("Seating Grid:");
        for (int i = 0; i < showTime.getSeats().size(); i++) {
            Seat seat = showTime.getSeats().get(i);
            System.out.print(seat.getSeatNumber() + "[" + (seat.isBooked() ? "X" : "O") + "] ");

            if ((i + 1) % 5 == 0) {
                System.out.println();
            }
        }
    }

    public void viewBookingStatus() {
        
        for (String status : bookingStatus) {
            System.out.println(status);
        }
    }

    private ShowTime getShowTime(String date, String showTime, int movieChoice) {
        List<ShowTime> availableShowTimes = theatre.getShowTimes();
        if (movieChoice >= 1 && movieChoice <= availableShowTimes.size()) {
            return availableShowTimes.get(movieChoice - 1);
        }
        return null;
    }
}


public class MovieTicketBookingSimulator {

	public static void main(String[] args) {
		
     Scanner scanner = new Scanner(System.in);

     Movie AnimalMovie = new Movie("Animal");
     Movie SalarMovie = new Movie("Salar");
     Movie DunkiMovie = new Movie("Dunki");

     Theatre theatre = new Theatre("admin", "admin123");
     theatre.addShowTime("7:00 PM", 5, AnimalMovie);
     theatre.addShowTime("10:00 PM", 5, AnimalMovie);
     theatre.addShowTime("7:00 PM", 5, SalarMovie);
     theatre.addShowTime("10:00 PM", 5, SalarMovie);
     theatre.addShowTime("7:00 PM", 5, DunkiMovie);
     theatre.addShowTime("10:00 PM", 5, DunkiMovie);

     BookingSystem bookingSystem = new BookingSystem(theatre);

     System.out.print("Enter username: ");
     String username = scanner.nextLine();
     System.out.print("Enter password: ");
     String password = scanner.nextLine();

     if (theatre.getUsername().equals(username) && theatre.authenticate(password)) {
         System.out.println("Login successful.");
      
         while (true) {
        	 System.out.println("\n*******************************************\n");
             System.out.println("\tWelcome to Sathyam Cinemas-Chennai");
             System.out.println("*********************************************");
             System.out.println("\n1. Update Password");
             System.out.println("2. View Seating Arrangement");
             System.out.println("3. Book Ticket");
             System.out.println("4. View Booking Status");
             System.out.println("5. Logout");
             System.out.print("Enter your choice: ");

             int choice = scanner.nextInt();
             scanner.nextLine(); 

             switch (choice) {
                 case 1:
                     System.out.print("Enter new password: ");
                     String newPassword = scanner.nextLine();
                     theatre.updatePassword(newPassword);
                     break;

                 case 2:
                     System.out.println("Select a movie:");
                     System.out.println("1. Animal");
                     System.out.println("2. Salar");
                     System.out.println("3. Dunki");
                     System.out.print("Enter movie number: ");
                     int movieChoice = scanner.nextInt();
                     scanner.nextLine(); 

                     System.out.println("Select a show time:");
                     System.out.println("1. 7:00 PM");
                     System.out.println("2. 10:00 PM");
                     System.out.print("Enter show time number: ");
                     int showTimeChoice = scanner.nextInt();
                     scanner.nextLine(); 

                     String selectedDate = "Today"; 
                     String selectedShowTime = (showTimeChoice == 1) ? "7:00 PM" : "10:00 PM";

                     bookingSystem.viewSeatingArrangement(selectedDate, selectedShowTime, movieChoice);
                     break;
                 case 3:
                     System.out.print("Enter date (e.g., DD-MM-YYYY): ");
                     String date = scanner.nextLine();

                     System.out.println("Select a movie:");
                     System.out.println("1. Animal");
                     System.out.println("2. salar");
                     System.out.println("3. dunki");
                     System.out.print("Enter movie number: ");
                     movieChoice = scanner.nextInt();
                     scanner.nextLine(); 

                     System.out.println("Select a show time:");
                     System.out.println("1. 7:00 PM");
                     System.out.println("2. 10:00 PM");
                     System.out.print("Enter show time number: ");
                     showTimeChoice = scanner.nextInt();
                     scanner.nextLine(); 

                     String selectedShowTimeTicket = (showTimeChoice == 1) ? "7:00 PM" : "10:00 PM";

                     System.out.println("Available seat numbers: A1 A2 A3 A4 A5 B1 B2 B3 B4 B5 C1 C2 C3 C4 C5");
                     System.out.print("Enter seat selection (e.g., A2 A3): ");
                     String seatSelection = scanner.nextLine();

                                         String[] seats = seatSelection.split("\\s+");
                     double totalAmount = 0;

                     for (String seat : seats) {
                         boolean isSeatAvailable = bookingSystem.bookTicket(date, selectedShowTimeTicket, seat);

                         if (isSeatAvailable) {
                             totalAmount += 100; 
                         } else {
                             System.out.println("Seat " + seat + " is not available. Please choose another seat.");
                             totalAmount = 0; 
                             break;
                         }
                     }

                     if (totalAmount > 0) {
                         System.out.println("Your " + theatre.getShowTimes().get(movieChoice - 1).getMovie().getName() +
                                 " movie tickets for " + date + " " + selectedShowTimeTicket + " - Seats: " + seatSelection +  " Successfully booked.");
                         System.out.println("Total Amount Paid: $" + totalAmount);
                         System.out.println("Than you visit again!");
                         
                     }
                     break;

                 case 4:
                     bookingSystem.viewBookingStatus();
                     break;

                 case 5:
                     System.out.println("Logout successful.");
                     System.exit(0);

                 default:
                     System.out.println("Invalid choice. Please try again.");
             }
         }
     } else {
         System.out.println("Login failed. Invalid username or password.");
     }
 }
}