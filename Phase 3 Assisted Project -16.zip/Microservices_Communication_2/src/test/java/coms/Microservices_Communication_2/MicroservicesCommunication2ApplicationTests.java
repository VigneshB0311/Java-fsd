package coms.Microservices_Communication_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesCommunication2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
