package ValidateEmailID;

import java.util.Arrays;
import java.util.Scanner;

public class emailValidation {
    public static void main(String[] args) {
        // Array of email IDs
        String[] emailArray = {"ram.01@gmail.com", "mithra79@gmail.com", "arun.s@gmail.com","4praveen8@gmail.com","prabhu318@gmail.com"};

        // Taking user input
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the email ID to search: ");
        String searchEmail = scanner.nextLine();

        // Searching for the email ID
        boolean found = Arrays.asList(emailArray).contains(searchEmail);

        // Displaying the result
        if (found) {
            System.out.println("Email ID found!");
        } else {
            System.out.println("Email ID not found.");
        }
    }
}
