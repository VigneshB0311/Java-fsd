package com;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
// @WebServlet("/productDetails")
public class ProductServlet extends HttpServlet {
 protected void doPost(HttpServletRequest request, 
HttpServletResponse response) throws ServletException, IOException {
 // Get the form data
 int productId = 
Integer.parseInt(request.getParameter("productId"));
 String productName = request.getParameter("productName");
 String productDescription = 
request.getParameter("productDescription");
 double productPrice = 
Double.parseDouble(request.getParameter("productPrice"));
 // Create a new Product object
 Product product = new Product(productId, productName, 
productDescription, productPrice);
 // Store the product in the session
 HttpSession session = request.getSession();
 session.setAttribute("product", product);
 // Redirect to the product display page
 response.sendRedirect("productDisplay.jsp");
 }
}