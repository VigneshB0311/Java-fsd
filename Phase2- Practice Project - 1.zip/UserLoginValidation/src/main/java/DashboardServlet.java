
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (isUserLoggedIn(request)) {
            forwardToDashboardPage(request, response);
        } else {
            redirectToLoginPage(response);
        }
    }

    private boolean isUserLoggedIn(HttpServletRequest request) {
        return request.getSession().getAttribute("email") != null;
    }

    private void forwardToDashboardPage(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("dashboard.html").forward(request, response);
    }

    private void redirectToLoginPage(HttpServletResponse response) throws IOException {
        response.sendRedirect("login.html");
    }
}
