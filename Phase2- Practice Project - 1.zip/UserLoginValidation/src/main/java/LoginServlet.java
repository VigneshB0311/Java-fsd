
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Hard-coded values for demonstration purposes
        String validEmail = "user@example.com";
        String validPassword = "password123";

        if (isValidLogin(email, password, validEmail, validPassword)) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            redirectToDashboard(response);
        } else {
            redirectToErrorPage(response);
        }
    }

    private boolean isValidLogin(String email, String password, String validEmail, String validPassword) {
        return email.equals(validEmail) && password.equals(validPassword);
    }

    private void redirectToDashboard(HttpServletResponse response) throws IOException {
        response.sendRedirect("DashboardServlet");
    }

    private void redirectToErrorPage(HttpServletResponse response) throws IOException {
        response.sendRedirect("error.html");
    }
}
